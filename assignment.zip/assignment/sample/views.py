from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect

# Create your views here.
def index(request):
    return render(request,'home.html')
def upload(request):
    return render(request,'upload.html')
def drop(request):
    return render(request,'drop.html')