from django.urls import path
from django.conf.urls import url,include
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    url(r'index/$',views.index,name='index'),
    url(r'upload/$',views.upload,name='upload'),
    url(r'drop/$',views.drop,name='drop'),
]